<?php
include 'database.php';
session_start();

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];  // Logged-in user's ID

// Handle the mark as viewed
$data = json_decode(file_get_contents("php://input"), true);
$notification_id = $data['id'];

// Use a prepared statement to prevent SQL injection
$sql = "UPDATE notifications 
        SET status = 'viewed' 
        WHERE id = ? AND user_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $notification_id, $user_id); // "ii" indicates two integers

// Execute the query and check if successful
if ($stmt->execute()) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => $stmt->error]);
}

$stmt->close();
$conn->close();
?>
