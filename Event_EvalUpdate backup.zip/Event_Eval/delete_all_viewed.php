<?php
session_start();
include "database.php";

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    exit("Unauthorized access");
}

$data = json_decode(file_get_contents("php://input"));
$user_id = $data->user_id;

// Delete all viewed notifications for the specific user
$sql = "DELETE FROM notifications WHERE status = 'viewed' AND user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();

echo "All viewed notifications deleted";
?>
