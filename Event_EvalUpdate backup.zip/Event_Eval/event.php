<?php
include 'database.php';


$sql = "SELECT * FROM events";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>
    <script src="navbar/Navloader.js"></script>
    <link rel="stylesheet" href="style/event.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="chatbot/chatbot.css">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght@400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:wght@400&display=swap" rel="stylesheet">
</head>


<body>
    <div id="navbar"></div>
    <div class="navbarmargin" style="margin-top:88px">
        <main>
            <h1 style="padding: 30px;">Upcoming Events</h1>
            <div class="container">
                <ul class="card-list">
                    <?php
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            $fullDescription = $row['description'];
                            $shortDescription = strlen($fullDescription) > 30 ? substr($fullDescription, 0, 30) . "..." : $fullDescription;


                            // Ensure the background image path is valid
                            $backgroundImage = !empty($row['background_image']) && file_exists($row['background_image'])
                                ? $row['background_image']
                                : 'style/Images/default-background.jpg';


                            echo "<li class='card-item swiper-slide'>";
                            echo "<a href='#' class='card-link'>";
                            echo "<img src='" . htmlspecialchars($backgroundImage) . "' alt='Event Image' class='card-image'>";
                            echo "<div class='card-content'>";
                            echo "<label class='badge'>" . htmlspecialchars($row['event_name']) . "</label>";
                            echo "<div class='card-description-wrapper'>";
                            echo "<p class='card-description short'>" . htmlspecialchars($shortDescription) . "</p>";
                            echo "<p class='card-description full' style='display: none;'>" . htmlspecialchars($fullDescription) . "</p>";
                            echo "</div>";
                            echo "<label class='card-title'>Department: </label><p>" . htmlspecialchars($row['department']) . "</p>";
                            echo "<label class='card-title'>Date: </label><p>" . htmlspecialchars($row['event_date']) . "</p>";
                            echo "<button class='card-button expand-btn'>";
                            echo "<span class='material-symbols-outlined'>arrow_forward</span>";
                            echo "</button>";
                            echo "</div>";
                            echo "</a>";
                            echo "</li>";
                        }
                    } else {
                        echo "<p>No events found.</p>";
                    }
                    ?>
                </ul>
            </div>
        </main>
        <div class="container-main">
            <button id="chatbot-toggler">
            <span><img src='style/Images/chatlogo.png' style="height: 30px;"></span>
                <span class="material-symbols-rounded">close</span>
            </button>


            <div class="chatbot-popup">
                <div class="chat-header">
                    <div class="header-info">
                        <img class="chatbot-logo" src="style/Images/chatbot.png" width="50" height="50" alt="Chatbot Logo">
                        <h2 class="logo-text">Evalus Chatbot</h2>
                    </div>
                    <button id="close-chatbot" class="material-symbols-rounded">keyboard_arrow_down</button>
                </div>


                <div class="chat-body">
                    <div class="message bot-message">
                        <img class="chatbot-logo" src="style/Images/chatbot-black.png" width="35" height="35" alt="Chatbot Logo">
                        <div class="message-text"> Hello there! I'm Evalus. <br /> What can I assist you with today? I'm here to help! </div>
                    </div>
                </div>


                <div class="chat-footer">
                    <form action="#" class="chat-form">
                        <textarea placeholder="Message..." class="message-input" required></textarea>
                        <div class="chat-controls">
                            <button type="button" id="emoji-picker" class="material-symbols-outlined">sentiment_satisfied</button>
                            <div class="file-upload-wrapper">
                                <input type="file" accept="image/*" id="file-input" hidden />
                                <img src="#" />
                                <button type="button" id="file-upload" class="material-symbols-rounded">attach_file</button>
                                <button type="button" id="file-cancel" class="material-symbols-rounded">close</button>
                            </div>
                            <button type="submit" id="send-message" class="material-symbols-rounded">arrow_upward</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/emoji-mart@latest/dist/browser.js"></script>
        <script src="chatbot/chatbot.js"></script>
        <script src="navbar/navmover.js"></script>
        <script>
            document.addEventListener('DOMContentLoaded', () => {
                document.querySelectorAll('.expand-btn').forEach(button => {
                    button.addEventListener('click', (e) => {
                        const cardContent = e.target.closest('.card-content');
                        const shortDesc = cardContent.querySelector('.card-description.short');
                        const fullDesc = cardContent.querySelector('.card-description.full');
                        if (shortDesc.style.display === "none") {
                            shortDesc.style.display = "";
                            fullDesc.style.display = "none";
                        } else {
                            shortDesc.style.display = "none";
                            fullDesc.style.display = "";
                        }
                    });
                });
            });
        </script>
</body>


</html>
