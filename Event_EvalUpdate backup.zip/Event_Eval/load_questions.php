<?php
include('database.php');

$event_id = $_GET['event_id'];

$sql = "SELECT id, question_text, question_type FROM questions WHERE event_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $event_id);
$stmt->execute();
$result = $stmt->get_result();

$questions = [];

while ($row = $result->fetch_assoc()) {
    $question = $row;
    
    if ($row['question_type'] === 'multiplechoice') {
        $options_sql = "SELECT option_text FROM options WHERE question_id = ?";
        $options_stmt = $conn->prepare($options_sql);
        $options_stmt->bind_param("i", $row['id']);
        $options_stmt->execute();
        $options_result = $options_stmt->get_result();
        
        $options = [];
        while ($option_row = $options_result->fetch_assoc()) {
            $options[] = $option_row['option_text'];
        }
        $question['options'] = $options;
    }

    $questions[] = $question;
}

echo json_encode($questions);
?>
