<?php
include 'database.php';

session_start(); // Ensure that sessions are started to retrieve logged-in user info

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Fetch form data
    $event_name = mysqli_real_escape_string($conn, $_POST['form_name']);
    $department = mysqli_real_escape_string($conn, $_POST['departmentinfo']);
    $event_date = $_POST['dateinfo'];
    $description = mysqli_real_escape_string($conn, $_POST['descriptioninfo']);

    // Handle background image upload
    $upload_dir = 'uploads/';
    $background_image_path = NULL;
    if (isset($_FILES['background_upload']) && $_FILES['background_upload']['error'] === 0) {
        $image_name = preg_replace('/[^a-zA-Z0-9_\.-]/', '_', basename($_FILES['background_upload']['name'])); // Sanitize file name
        $image_path = $upload_dir . time() . '_' . $image_name;
        if (move_uploaded_file($_FILES['background_upload']['tmp_name'], $image_path)) {
            $background_image_path = $image_path; // Save the image path
        } else {
            echo "Background image upload failed.";
        }
    }

    // Insert event data into the database
    $sql = "INSERT INTO events (event_name, department, event_date, description, background_image)
            VALUES ('$event_name', '$department', '$event_date', '$description', '$background_image_path')";

    if (mysqli_query($conn, $sql)) {
        $event_id = mysqli_insert_id($conn);

        // Ensure that a user is logged in (i.e., user_id exists in session)
        if (isset($_SESSION['user_id'])) {
            $user_id = $_SESSION['user_id'];  // Get the logged-in user's ID

            // Insert notification with 'unread' status
            $sql_notification = "INSERT INTO notifications (event_id, user_id, status)
                                 VALUES ('$event_id', '$user_id', 'unread')";
            if (!mysqli_query($conn, $sql_notification)) {
                echo "Error inserting notification: " . mysqli_error($conn);
            }
        } else {
            echo "User not logged in. Unable to insert notification.";
        }

        // Handle questions and options
        if (isset($_POST['questions']) && is_array($_POST['questions'])) {
            foreach ($_POST['questions'] as $question) {
                $question_text = mysqli_real_escape_string($conn, $question['text']);
                $question_type = mysqli_real_escape_string($conn, $question['type']);

                $sql_question = "INSERT INTO questions (event_id, question_text, question_type)
                                 VALUES ('$event_id', '$question_text', '$question_type')";
                if (mysqli_query($conn, $sql_question)) {
                    $question_id = mysqli_insert_id($conn);

                    if ($question_type === 'multiplechoice' && isset($question['options']) && is_array($question['options'])) {
                        foreach ($question['options'] as $option) {
                            $option_text = mysqli_real_escape_string($conn, $option);
                            $sql_option = "INSERT INTO options (question_id, option_text)
                                           VALUES ('$question_id', '$option_text')";
                            mysqli_query($conn, $sql_option);
                        }
                    }
                }
            }
        }
    }
}

mysqli_close($conn);
?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Creation</title>
    <script src="navbar/AdminNavloader.js" defer></script>
    <link rel="stylesheet" href="style/eventcreation.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="chatbot/chatbot.css">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght@400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:wght@400&display=swap" rel="stylesheet">
</head>


<body>
    <div id="adminbar"></div>
    <div class="navbarmargin" style="margin-top:88px">
        <main>
            <h1 style="padding: 30px 20px 30px 20px; font-size:30px;">Event Creation Evaluation Form</h1>

            <form action="eventcreation.php" method="POST" enctype="multipart/form-data">
                <div class="container">
                    <div class="head-form">
                        <div class="form-name-container">
                            <h2>Form Name</h2>
                            <input type="text" name="form_name" placeholder="Untitled Form" required style="width: 400px;">
                        </div>
                        <div class="input-group">
                            <input type="submit" value="Deploy" style="border-radius: 50px;;">
                        </div>
                    </div>


                    <h2 style="margin: 40px 30px 40px 30px; color:#EC1D27">Event Information:</h2>

                    <div class="form-description">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="departmentinfo">Department:</label>
                                <select name="departmentinfo" id="departmentinfo" required>
                                    <option value="" disabled selected>Select Department</option>
                                    <option value="CET">CET</option>
                                    <option value="CTE">CTE</option>
                                    <option value="CAS">CAS</option>
                                    <option value="CCJE">CCJE</option>
                                    <option value="CABEIHM">CABEIHM</option>
                                    <option value="CICS">CICS</option>
                                </select>
                            </div>


                            <div class="form-group">
                                <label for="dateinfo">Date:</label>
                                <input type="date" name="dateinfo" id="dateinfo" required>
                            </div>
                        </div>


                        <div class="form-group description">
                            <label for="descriptioninfo">Description:</label>
                            <textarea name="descriptioninfo" id="descriptioninfo" rows="4" placeholder="Add your short description" required></textarea>
                        </div>


                        <div class="form-group">
                            <label for="background_upload">Event Background Image:</label>
                            <input type="file" name="background_upload" id="background_upload" accept="image/*" required>
                        </div>
                    </div>


                    <h2 style="margin: 40px 30px 40px 30px; color:#EC1D27">Evaluation Questions:</h2>
                    <div class="form-question">
                        <!-- New question group ay papasok dine -->
                    </div>


                    <div class="add-question">
                        <button type="button"><i class="fas fa-plus"></i> Add New Question</button>
                    </div>
                </div>
            </form>
        </main>


        <div id="popup" class="popup-overlay">
            <div class="popup-content">
                <h2><?= htmlspecialchars($successMessage) ?></h2>
                <button id="closePopup">Okay</button>
            </div>
        </div>
    </div>
    <div class="container-main">
        <button id="chatbot-toggler">
            <span><img src='style/Images/chatlogo.png' style="height: 30px;"></span>
            <span class="material-symbols-rounded">close</span>
        </button>


        <div class="chatbot-popup">
            <div class="chat-header">
                <div class="header-info">
                    <img class="chatbot-logo" src="style/Images/chatbot.png" width="50" height="50" alt="Chatbot Logo">
                    <h2 class="logo-text">Evalus Chatbot</h2>
                </div>
                <button id="close-chatbot" class="material-symbols-rounded">keyboard_arrow_down</button>
            </div>


            <div class="chat-body">
                <div class="message bot-message">
                    <img class="chatbot-logo" src="style/Images/chatbot-black.png" width="35" height="35" alt="Chatbot Logo">
                    <div class="message-text"> Hello there! I'm Evalus. <br /> What can I assist you with today? I'm here to help! </div>
                </div>
            </div>


            <div class="chat-footer">
                <form action="#" class="chat-form">
                    <textarea placeholder="Message..." class="message-input" required></textarea>
                    <div class="chat-controls">
                        <button type="button" id="emoji-picker" class="material-symbols-outlined">sentiment_satisfied</button>
                        <div class="file-upload-wrapper">
                            <input type="file" accept="image/*" id="file-input" hidden />
                            <img src="#" />
                            <button type="button" id="file-upload" class="material-symbols-rounded">attach_file</button>
                            <button type="button" id="file-cancel" class="material-symbols-rounded">close</button>
                        </div>
                        <button type="submit" id="send-message" class="material-symbols-rounded">arrow_upward</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/emoji-mart@latest/dist/browser.js"></script>
    <script src="chatbot/chatbot.js"></script>
    <script src="navbar/navmover.js"></script>
    <script src="scripts/eventcreation.js"></script>
    <script>
        // JavaScript to handle popup
        const successMessage = <?= json_encode(!empty($successMessage)) ?>;
        if (successMessage) {
            const popup = document.getElementById('popup');
            popup.style.display = 'block';


            // Close the popup on button click
            document.getElementById('closePopup').addEventListener('click', () => {
                popup.style.display = 'none';
            });
        }
    </script>
</body>

</html>