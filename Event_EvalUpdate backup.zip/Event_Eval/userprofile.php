<?php
include('database.php');


session_start();
$userId = $_SESSION['user_id'] ?? null;


// Ensure the user is logged in
if (!$userId) {
    header("Location: login.php");
    exit();
}


// Fetch user profile data
function getProfile($userId) {
    global $conn;
    $query = "
        SELECT
            r.firstName,
            r.lastName,
            r.email,
            r.department,
            COALESCE(up.address, '') AS address,
            COALESCE(up.emergency_contact, '') AS emergency_contact,
            COALESCE(up.blood_type, '') AS blood_type,
            COALESCE(up.campus_address, '') AS campus_address,
            COALESCE(up.profilePicture, 'uploads/Default.jpg') AS profilePicture,
            CONCAT(r.firstName, ' ', r.lastName) AS username
        FROM register r
        LEFT JOIN User_Profile up ON r.id = up.userId
        WHERE r.id = ?
    ";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    if (!$result) {
        die("Execute failed: " . $stmt->error);
    }
    return $result->fetch_assoc() ?: [];
}


// Update profile information
function updateProfile($userId, $data) {
    global $conn;


    // Ensure the profilePicture column exists in the database
    $checkColumnQuery = "SHOW COLUMNS FROM register LIKE 'profilePicture'";
    $result = $conn->query($checkColumnQuery);


    if ($result->num_rows == 0) {
        // If the column does not exist, attempt to add it (optional step)
        $alterQuery = "ALTER TABLE register ADD COLUMN profilePicture VARCHAR(255)";
        if (!$conn->query($alterQuery)) {
            die("Error adding profilePicture column: " . $conn->error);
        }
    }


    // Update the main user information in the 'register' table
    $registerQuery = "
        UPDATE register
        SET firstName = ?,
            lastName = ?,
            email = ?,
            department = ?,
            profilePicture = ?  -- Make sure this field is updated in 'register' table
        WHERE id = ?
    ";
    $stmt = $conn->prepare($registerQuery);
    $stmt->bind_param(
        "sssssi",
        $data['first_name'],
        $data['last_name'],
        $data['email'],
        $data['department'],
        $data['profile_picture'],  // Bind the profile picture field
        $userId
    );


    if (!$stmt->execute()) {
        die("Error updating user information: " . $stmt->error);
    }


    // Check if the profile exists in the 'User_Profile' table
    $checkQuery = "SELECT 1 FROM User_Profile WHERE userId = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();


    if ($result->num_rows > 0) {
        // Update existing profile details in 'User_Profile'
        $profileQuery = "
            UPDATE User_Profile
            SET address = ?,
                emergency_contact = ?,
                blood_type = ?,
                campus_address = ?,
                profilePicture = ?  -- Update the profile picture in 'User_Profile'
            WHERE userId = ?
        ";
    } else {
        // Insert new profile details into 'User_Profile'
        $profileQuery = "
            INSERT INTO User_Profile (userId, address, emergency_contact, blood_type, campus_address, profilePicture)
            VALUES (?, ?, ?, ?, ?, ?)
        ";
    }


    $stmt = $conn->prepare($profileQuery);


    if ($result->num_rows > 0) {
        // Bind parameters for UPDATE
        $stmt->bind_param(
            "sssssi",
            $data['address'],
            $data['emergency_contact'],
            $data['blood_type'],
            $data['campus_address'],
            $data['profile_picture'],  // Bind profile picture path
            $userId
        );
    } else {
        // Bind parameters for INSERT
        $stmt->bind_param(
            "isssss",
            $userId,
            $data['address'],
            $data['emergency_contact'],
            $data['blood_type'],
            $data['campus_address'],
            $data['profile_picture']  // Bind profile picture path
        );
    }


    if ($stmt->execute()) {
        return "Profile updated successfully.";
    } else {
        return "Error updating profile details: " . $stmt->error;
    }
}








// Handle profile picture upload
function handleTemporaryUpload($file) {
    $tempDir = "temp/uploads/";
    if (!is_dir($tempDir)) {
        mkdir($tempDir, 0777, true); // Ensure the temp directory exists
    }


    $fileName = basename($file["name"]);
    $uniqueFileName = uniqid() . "_" . $fileName;
    $tempFile = $tempDir . $uniqueFileName;


    // Validate if the file is an image
    $check = @getimagesize($file["tmp_name"]);
    if ($check === false) {
        return ["error" => "File is not a valid image."];
    }


    // Validate file size (5MB max)
    if ($file["size"] > 5000000) {
        return ["error" => "File is too large. Maximum size is 5MB."];
    }


    // Validate file extension
    $imageFileType = strtolower(pathinfo($tempFile, PATHINFO_EXTENSION));
    if (!in_array($imageFileType, ["jpg", "jpeg", "png", "gif"])) {
        return ["error" => "Only JPG, JPEG, PNG, and GIF files are allowed."];
    }


    // Move the file to the temporary directory
    if (move_uploaded_file($file["tmp_name"], $tempFile)) {
        return ["success" => true, "path" => $tempFile];
    } else {
        return ["error" => "Error uploading photo. Check permissions for the 'temp/uploads' directory."];
    }
}


// Delete profile picture
function deleteProfilePicture($userId) {
    global $conn;
    $query = "SELECT profilePicture FROM User_Profile WHERE userId = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $profile = $result->fetch_assoc();


    if ($profile && $profile['profilePicture'] !== 'uploads/Default.jpg') {
        @unlink($profile['profilePicture']);
    }


    $updateQuery = "UPDATE User_Profile SET profilePicture = 'uploads/Default.jpg' WHERE userId = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("i", $userId);
    return $stmt->execute() ? "Profile picture deleted successfully." : "Error deleting profile picture: " . $conn->error;
}


// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle profile picture upload
    if (isset($_POST['upload']) && isset($_FILES['profile_picture'])) {
        $result = handleTemporaryUpload($_FILES['profile_picture']);
        if (isset($result['success'])) {
            $_SESSION['temp_profile_picture'] = $result['path']; // Save the temporary file path in session
        } else {
            echo $result['error']; // Handle error (invalid file, size, etc.)
        }
    }
    // Handle saving the profile data
    elseif (isset($_POST['save'])) {
        // Gather profile data (including first_name, last_name, etc.)
        $data = [
            'first_name' => $_POST['first_name'],
            'last_name' => $_POST['last_name'],
            'email' => $_POST['email'],
            'department' => $_POST['department'],
            'address' => $_POST['address'],
            'emergency_contact' => $_POST['emergency_contact'],
            'blood_type' => $_POST['blood_type'],
            'campus_address' => $_POST['campus_address']
        ];


        // Check if a temporary profile picture is available
        if (!empty($_SESSION['temp_profile_picture'])) {
            $tempPicture = $_SESSION['temp_profile_picture'];
            $finalPath = str_replace("temp/uploads/", "uploads/", $tempPicture);


            if (!is_dir("uploads")) {
                mkdir("uploads", 0777, true);
            }


            if (rename($tempPicture, $finalPath)) {
                $data['profile_picture'] = $finalPath;
            } else {
                echo "Error moving the profile picture to the final directory.";
                exit();
            }


            unset($_SESSION['temp_profile_picture']);
        }


        // Update the profile in the database
        $updateResult = updateProfile($userId, $data);
        if ($updateResult === "Profile updated successfully.") {
            header("Location: viewprofile.php");
            exit();
        } else {
            echo $updateResult; // Handle any errors
        }
    }
    // Handle profile picture deletion
    elseif (isset($_POST['delete'])) {
        echo deleteProfilePicture($userId);
    }
}




// Fetch updated profile data
$profile = getProfile($userId);
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <script src="navbar/Navloader.js" defer></script>
    <link rel="stylesheet" href="style/userprofile.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=arrow_forward" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="style/upload.css">
</head>
<body>
<div id="navbar"></div>
<div class="navbarmargin" style="margin-top:88px; margin-left: 260px;">
    <main>
        <h1 style="color: #EC1D27; margin: 10px;">Profile</h1>  
        <h2 style="margin-left: 10px;">My Details</h2>
        <div class="profile-container">
        <div class="profile-container">
        <div class="profile-header">
        <img src="<?php echo $_SESSION['temp_profile_picture'] ?? $profile['profilePicture']; ?>" alt="Profile Picture">
            <div>
            <h2><?php echo htmlspecialchars($profile['username']); ?></h2>
            <h3><?php echo htmlspecialchars($profile['department']); ?></h3>
            </div>
            <div class="profile-buttons">
                <button class="btn upload-btn" id="openUploadModal">Upload New Photo</button>
                <button class="btn delete-btn" id="openDeleteModal">Delete</button>
            </div>
        </div>
        <div class="form-section">
            <form action="userprofile.php" method="POST">
                <input type="hidden" name="user_id" value="<?php echo $userId; ?>">
                <div class="form-row">
                    <div class="form-group">
                        <label for="first_name">First Name</label>
                        <input type="text" name="first_name" value="<?php echo htmlspecialchars($profile['firstName']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="last_name">Last Name</label>
                        <input type="text" name="last_name" value="<?php echo htmlspecialchars($profile['lastName']); ?>" required>
                    </div>
                </div>
            <div class="form-row">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" value="<?php echo htmlspecialchars($profile['firstName']) . ' ' . htmlspecialchars($profile['lastName']); ?>" readonly>
            </div>
        </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($profile['email']); ?>" required>
                    </div>
                <div class="form-group">
                    <label for="department">Department</label>
                    <select name="department" id="department" required>
                    <option value="" disabled selected>Select Department</option>
                 <?php
                  $departments = ["CET", "CTE", "CAS", "CCJE", "CABEIHM", "CICS"];
                     foreach ($departments as $department): ?>
                    <option value="<?php echo htmlspecialchars($department); ?>"
                    <?php echo (isset($profile['department']) && $profile['department'] === $department) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($department); ?>
              </option>
            <?php endforeach; ?>
         </select>
                </div>
            </div>
        <form action="userprofile.php" method="POST">
        <div>
            <label for="address">Address:</label>
            <input type="text" name="address" value="<?php echo htmlspecialchars($profile['address']); ?>" required>
        </div>
        <div>
            <label for="emergency_contact">Emergency Contact:</label>
            <input type="text" name="emergency_contact" value="<?php echo htmlspecialchars($profile['emergency_contact']); ?>" required>
        </div>
        <div class="form-group">
    <label for="blood_type">Blood Type:</label>
    <select name="blood_type" id="blood_type" required>
        <option value="" disabled <?php echo empty($profile['blood_type']) ? 'selected' : ''; ?>>Select Blood Type</option>
        <option value="A+" <?php echo $profile['blood_type'] === 'A+' ? 'selected' : ''; ?>>A+</option>
        <option value="A-" <?php echo $profile['blood_type'] === 'A-' ? 'selected' : ''; ?>>A-</option>
        <option value="B+" <?php echo $profile['blood_type'] === 'B+' ? 'selected' : ''; ?>>B+</option>
        <option value="B-" <?php echo $profile['blood_type'] === 'B-' ? 'selected' : ''; ?>>B-</option>
        <option value="AB+" <?php echo $profile['blood_type'] === 'AB+' ? 'selected' : ''; ?>>AB+</option>
        <option value="AB-" <?php echo $profile['blood_type'] === 'AB-' ? 'selected' : ''; ?>>AB-</option>
        <option value="O+" <?php echo $profile['blood_type'] === 'O+' ? 'selected' : ''; ?>>O+</option>
        <option value="O-" <?php echo $profile['blood_type'] === 'O-' ? 'selected' : ''; ?>>O-</option>
    </select>
</div>
        <div>
            <label for="campus_address">Campus Address:</label>
            <input type="text" name="campus_address" value="<?php echo htmlspecialchars($profile['campus_address']); ?>" required>
            <div class="form-buttons">
                    <button type="submit" name="save" class="btn save-btn">Save</button>
                    <button type="reset" class="btn discard-btn" onclick="window.location.reload()">Discard</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
<!-- Upload Modal -->
<div id="uploadModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeUploadModal">&times;</span>
        <h2>Upload New Profile Picture</h2>
        <form action="userprofile.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="user_id" value="<?php echo $userId; ?>">
            <input type="file" name="profile_picture" required>
            <div class="modal-buttons">
                <button type="submit" name="upload" class="btn save-btn">Upload</button>
                <button type="button" id="cancelUpload" class="btn discard-btn">Cancel</button>
            </div>
        </form>
    </div>
</div>


<!-- Delete Modal -->
<div id="deleteModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeDeleteModal">&times;</span>
        <h2>Delete Profile Picture</h2>
        <p>Are you sure you want to delete your profile picture?</p>
        <form action="userprofile.php" method="POST">
            <input type="hidden" name="user_id" value="<?php echo $userId; ?>">
            <div class="modal-buttons">
                <button type="submit" name="delete" class="btn delete-btn">Delete</button>
                <button type="button" id="cancelDelete" class="btn discard-btn">Cancel</button>
            </div>
        </form>
    </div>
</div>




<script>
    const uploadModal = document.getElementById("uploadModal");
    const deleteModal = document.getElementById("deleteModal");
    const openUploadModal = document.getElementById("openUploadModal");
    const openDeleteModal = document.getElementById("openDeleteModal");
    const closeUploadModal = document.getElementById("closeUploadModal");
    const closeDeleteModal = document.getElementById("closeDeleteModal");
    const cancelUpload = document.getElementById("cancelUpload");
    const cancelDelete = document.getElementById("cancelDelete");








    openUploadModal.addEventListener("click", () => {
        uploadModal.style.display = "block";
    });








    openDeleteModal.addEventListener("click", () => {
        deleteModal.style.display = "block";
    });








    closeUploadModal.addEventListener("click", () => {
        uploadModal.style.display = "none";
    });








    closeDeleteModal.addEventListener("click", () => {
        deleteModal.style.display = "none";
    });








    cancelUpload.addEventListener("click", () => {
        uploadModal.style.display = "none";
    });








    cancelDelete.addEventListener("click", () => {
        deleteModal.style.display = "none";
    });








    window.onclick = (event) => {
        if (event.target === uploadModal) {
            uploadModal.style.display = "none";
        }
        if (event.target === deleteModal) {
            deleteModal.style.display = "none";
        }
    };
</script>
</body>
</html>



