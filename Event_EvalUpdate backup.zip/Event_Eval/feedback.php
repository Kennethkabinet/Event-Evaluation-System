<?php 
session_start();
include('database.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$sort_order = 'DESC';

if (isset($_GET['sort'])) {
    if ($_GET['sort'] == 'option2') {
        $sort_order = 'ASC'; 
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $event_id = $_POST['event_id'];
    $user_id = $_SESSION['user_id']; 
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $experience_rating = $_POST['experience'];
    $comments = mysqli_real_escape_string($conn, $_POST['comments']);


    $check_feedback_sql = "SELECT * FROM feedback WHERE event_id = '$event_id' AND user_id = '$user_id'";
    $check_feedback_result = mysqli_query($conn, $check_feedback_sql);

    if (mysqli_num_rows($check_feedback_result) == 0) {

        $sql = "INSERT INTO feedback (event_id, user_id, experience_rating, comments, status) 
                VALUES ('$event_id', '$user_id', '$experience_rating', '$comments', 'pending')";

        if (mysqli_query($conn, $sql)) {

            $update_sql = "UPDATE feedback SET status = 'complete' WHERE event_id = '$event_id' AND user_id = '$user_id' AND status = 'pending'";

            if (mysqli_query($conn, $update_sql)) {
                echo "Feedback submitted and status updated successfully!";
            } else {
                echo "Error updating status: " . mysqli_error($conn);
            }
        } else {
            echo "Error inserting feedback: " . mysqli_error($conn);
        }
    } else {
        echo "You have already submitted feedback for this event.";
    }
}


$sql = "SELECT events.event_name, events.department, events.event_date, events.id 
        FROM events
        LEFT JOIN feedback ON events.id = feedback.event_id AND feedback.user_id = '$_SESSION[user_id]'
        WHERE feedback.status != 'complete' OR feedback.status IS NULL
        ORDER BY event_date $sort_order";
$result = mysqli_query($conn, $sql);


$completed_feedback_sql = "SELECT event_name, department, event_date 
                           FROM events
                           JOIN feedback ON events.id = feedback.event_id
                           WHERE feedback.status = 'complete' 
                           AND feedback.user_id = '$_SESSION[user_id]'
                           ORDER BY event_date $sort_order";
$completed_feedback_result = mysqli_query($conn, $completed_feedback_sql);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>
    <script src="navbar/Navloader.js" defer></script>
    <link rel="stylesheet" href="style/feedback.css">
    <link rel="stylesheet" href="style/table.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=arrow_forward" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="chatbot/chatbot.css">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght@400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:wght@400&display=swap" rel="stylesheet">
</head>

<body>
    <div id="navbar"></div>
    <div class="navbarmargin" style="margin-top:88px">
    <main>
            <h1 style="padding: 30px;">Upcoming Events</h1>
            <div class="header-container">
                <h2>All Evaluated Events</h2>
                <div>
                    <label for="dropdown">Sort by: </label>
                    <select id="dropdown" name="dropdown" onchange="location = this.value;">
                        <option value="?sort=option1" <?php echo $sort_order == 'DESC' ? 'selected' : ''; ?>>Latest</option>
                        <option value="?sort=option2" <?php echo $sort_order == 'ASC' ? 'selected' : ''; ?>>Oldest</option>
                    </select>
                </div>
            </div>
            <div class="main-container-tables">
            <div class="table-labels">
                    <h2>Pending Feedback Form</h2>
                    <h2>Answered Feedback Form</h2>
                </div>
            <div class="table-wrapper">
                <div class="table-container">
                    <table class="styled-table">
                        <thead>
                            <tr>
                                <th>Event Name</th>
                                <th>Department</th>
                                <th>Date</th>
                                <th>Create Feedback</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if (mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo '<tr>
                                        <td>' . htmlspecialchars($row['event_name']) . '</td>
                                        <td>' . htmlspecialchars($row['department']) . '</td>
                                        <td>' . htmlspecialchars($row['event_date']) . '</td>
                                        <td><button class="evaluate-btn" data-event-id="' . $row['id'] . '" style="background-color: #b3e6cc; color: #006622; border: 1px solid #006622; padding: 5px 15px; border-radius: 5px; cursor: pointer;">Evaluate</button></td>
                                    </tr>';
                                }
                            } else {
                                echo '<tr><td colspan="4">No events found</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

                <div class="table-container">
                    <table class="styled-table">
                        <thead>
                            <tr>
                                <th>Event Name</th>
                                <th>Department</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if (mysqli_num_rows($completed_feedback_result) > 0) {
                                while ($row = mysqli_fetch_assoc($completed_feedback_result)) {
                                    echo '<tr>
                                        <td>' . htmlspecialchars($row['event_name']) . '</td>
                                        <td>' . htmlspecialchars($row['department']) . '</td>
                                        <td>' . htmlspecialchars($row['event_date']) . '</td>
                                    </tr>';
                                }
                            } else {
                                echo '<tr><td colspan="3">No completed feedbacks found</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            </div>
        </main>


        <div class="container-main">
            <button id="chatbot-toggler">
                <span><img src='style/Images/chatlogo.png' style="height: 30px;"></span>
                <span class="material-symbols-rounded">close</span>
            </button>

            <div class="chatbot-popup">
                <div class="chat-header">
                    <div class="header-info">
                        <img class="chatbot-logo" src="style/Images/chatbot.png" width="50" height="50" alt="Chatbot Logo">
                        <h2 class="logo-text">Evalus Chatbot</h2>
                    </div>
                    <button id="close-chatbot" class="material-symbols-rounded">keyboard_arrow_down</button>
                </div>


                <div class="chat-body">
                    <div class="message bot-message">
                        <img class="chatbot-logo" src="style/Images/chatbot-black.png" width="35" height="35" alt="Chatbot Logo">
                        <div class="message-text"> Hello there! I'm Evalus. <br /> What can I assist you with today? I'm here to help! </div>
                    </div>
                </div>


                <div class="chat-footer">
                    <form action="#" class="chat-form">
                        <textarea placeholder="Message..." class="message-input" required></textarea>
                        <div class="chat-controls">
                            <button type="button" id="emoji-picker" class="material-symbols-outlined">sentiment_satisfied</button>
                            <div class="file-upload-wrapper">
                                <input type="file" accept="image/*" id="file-input" hidden />
                                <img src="#" />
                                <button type="button" id="file-upload" class="material-symbols-rounded">attach_file</button>
                                <button type="button" id="file-cancel" class="material-symbols-rounded">close</button>
                            </div>
                            <button type="submit" id="send-message" class="material-symbols-rounded">arrow_upward</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <section class="popup-outer">
            <div class="popup-box">
                <i id="close" class='bx bx-x close'></i>
                <div class="text" style="text-align: center;">
                    <span class="create-feedback">Create Feedback</span>
                </div>
                <form method="POST" action="">
                    <input type="hidden" name="event_id" value="">
                    <label>Name</label>
                    <input type="text" name="name" placeholder="Enter your name" required>

                    <label>Email</label>
                    <input type="email" name="email" placeholder="Enter your email" required>

                    <label>Share your experience in scaling</label>

                    <div class="rating">
                        <div class="emoji-container">
                            <span class="emoji emoji-1">😣</span>
                            <span class="emoji emoji-2">😞</span>
                            <span class="emoji emoji-3">😐</span>
                            <span class="emoji emoji-4">😊</span>
                            <span class="emoji emoji-5">😍</span>
                        </div>
                        <div class="label-container">
                            <span>Worst</span>
                            <span>Not Good</span>
                            <span>Fine</span>
                            <span>Look Good</span>
                            <span>Very Good</span>
                        </div>
                        <input type="range" name="experience" min="1" max="5" value="3" id="experience" required>
                    </div>
                    <textarea name="comments" placeholder="Add your comments..." required></textarea>

                    <div class="button">
                        <button type="button" id="cancel" class="cancel">Cancel</button>
                        <button type="submit" class="send">Submit</button>
                    </div>
                </form>
            </div>
        </section>
        <script src="https://cdn.jsdelivr.net/npm/emoji-mart@latest/dist/browser.js"></script>
        <script src="chatbot/chatbot.js"></script>
        <script src="navbar/navmover.js"></script>
        <script>
            const popupOuter = document.querySelector('.popup-outer');
            const closeBtns = document.querySelectorAll('.close, #cancel');
            const evaluateBtns = document.querySelectorAll('.evaluate-btn');


            evaluateBtns.forEach(button => {
                button.addEventListener('click', () => {
                    const event_id = button.getAttribute('data-event-id');
                    document.querySelector('input[name="event_id"]').value = event_id;
                    popupOuter.classList.add('active');
                });
            });

            closeBtns.forEach(btn => {
                btn.addEventListener('click', () => {
                    popupOuter.classList.remove('active');
                });
            });
        </script>

        <script>
            const rangeInput = document.querySelector('input[name="experience"]');
            const emojis = document.querySelectorAll('.emoji');

            rangeInput.addEventListener('input', function() {
                const value = parseInt(rangeInput.value);

                emojis.forEach((emoji, index) => {
                    if (index + 1 === value) {
                        emoji.classList.add('selected');
                        emoji.classList.remove('faded');
                    } else {
                        emoji.classList.remove('selected');
                        emoji.classList.add('faded');
                    }
                });
            });

            rangeInput.dispatchEvent(new Event('input'));
        </script>
    </div>
</body>

</html>

<?php
mysqli_close($conn);
?>