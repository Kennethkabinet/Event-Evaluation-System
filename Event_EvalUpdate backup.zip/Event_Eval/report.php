<?php
include('database.php');

// Fetch event names and IDs
$sql = "SELECT event_name, id FROM events";
$result = $conn->query($sql);

$event_names = [];
$event_ids = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $event_names[] = $row['event_name'];
        $event_ids[] = $row['id'];
    }
}

$selected_event = isset($_GET['event']) ? $_GET['event'] : 'all-events';

// Get total respondents and feedback users
if ($selected_event === 'all-events') {
    $sql_respondents = "SELECT COUNT(DISTINCT user_id) AS total_respondents FROM question_answers";
    $sql_feedback_users = "SELECT COUNT(DISTINCT user_id) AS total_feedback_users FROM feedback";
} else {
    $sql_respondents = "SELECT COUNT(DISTINCT user_id) AS total_respondents FROM question_answers WHERE event_id = ?";
    $sql_feedback_users = "SELECT COUNT(DISTINCT user_id) AS total_feedback_users FROM feedback WHERE event_id = ?";
}

$stmt = $conn->prepare($sql_respondents);
if ($selected_event !== 'all-events') {
    $stmt->bind_param("i", $selected_event);
}
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$total_respondents = $row['total_respondents'];

$stmt = $conn->prepare($sql_feedback_users);
if ($selected_event !== 'all-events') {
    $stmt->bind_param("i", $selected_event);
}
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$total_feedback_users = $row['total_feedback_users'];

// Get event names and respondents count
$sql = "SELECT e.event_name, COUNT(f.user_id) AS num_respondents 
        FROM events e 
        LEFT JOIN feedback f ON e.id = f.event_id 
        GROUP BY e.id";
$result = $conn->query($sql);

$respondents_count = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $respondents_count[] = $row['num_respondents'];
    }
}

// Get total number of events
$sql_total_events = "SELECT COUNT(*) as total_events FROM events";
$total_events_result = $conn->query($sql_total_events);
$total_events_row = $total_events_result->fetch_assoc();
$total_events = $total_events_row['total_events'];

// Analytics for questionnaire options
$sql_question_options = "SELECT q.question_text, o.option_text, COUNT(qa.id) AS num_answers
                         FROM question_answers qa
                         JOIN questions q ON qa.question_id = q.id
                         JOIN options o ON qa.answer = o.id
                         WHERE qa.event_id = ? 
                         GROUP BY q.id, o.id";

$question_options = [];
if ($selected_event !== 'all-events') {
    $stmt = $conn->prepare($sql_question_options);
    $stmt->bind_param("i", $selected_event);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $question_options[] = [
            'question' => $row['question_text'],
            'option' => $row['option_text'],
            'num_answers' => $row['num_answers']
        ];
    }
}

// Get questions and answers for the selected event
$questions_data = [];
if ($selected_event !== 'all-events') {
    $sql_questions = "
        SELECT 
            q.id AS question_id, 
            q.question_text, 
            q.question_type 
        FROM questions q
        WHERE q.event_id = ?";
    $stmt = $conn->prepare($sql_questions);
    $stmt->bind_param("i", $selected_event);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $question_id = $row['question_id'];
        $question_text = $row['question_text'];
        $question_type = $row['question_type'];

        $answers = [];
        if ($question_type === "multiple choice") {
            // SQL to get multiple-choice options and their selected user count
            $sql_answers = "
                SELECT 
                    o.option_text, 
                    COUNT(qa.id) AS num_selected
                FROM options o
                LEFT JOIN question_answers qa ON o.id = qa.answer AND qa.question_id = ?
                WHERE o.question_id = ?
                GROUP BY o.id
            ";
            $answer_stmt = $conn->prepare($sql_answers);
            $answer_stmt->bind_param("ii", $question_id, $question_id);
            $answer_stmt->execute();
            $answer_result = $answer_stmt->get_result();

            while ($answer_row = $answer_result->fetch_assoc()) {
                $answers[] = [
                    'option_text' => $answer_row['option_text'],
                    'num_selected' => $answer_row['num_selected']
                ];
            }
        } else {
            // For non-multiple-choice questions, just fetch answers
            $sql_answers = "
                SELECT qa.answer, COUNT(qa.id) AS num_selected
                FROM question_answers qa
                WHERE qa.question_id = ?
                GROUP BY qa.answer";
            $answer_stmt = $conn->prepare($sql_answers);
            $answer_stmt->bind_param("i", $question_id);
            $answer_stmt->execute();
            $answer_result = $answer_stmt->get_result();

            while ($answer_row = $answer_result->fetch_assoc()) {
                $answers[] = [
                    'option_text' => $answer_row['answer'], // Text of the answer
                    'num_selected' => $answer_row['num_selected'] // Number of users who selected it
                ];
            }
        }

        // Add the question and its answers to the questions_data array
        $questions_data[] = [
            'question_text' => $question_text,
            'question_type' => $question_type,
            'answers' => $answers
        ];
    }
}

$conn->close();
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports</title>
    <script src="navbar/AdminNavloader.js" defer></script>
    <link rel="stylesheet" href="style/table.css">
    <link rel="stylesheet" href="style/reports.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="chatbot/chatbot.css">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght@400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:wght@400&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>
    <div id="adminbar"></div>
    <div class="navbarmargin" style="margin-top:88px">
        <main>
            <h1 style="padding: 10px;">Reports</h1>

            <div class="main-container">

                <div class="dropdown-container">
                    <select id="event-select" class="dropdown" onchange="updateRespondents()">
                        <option value="all-events" <?php echo $selected_event === 'all-events' ? 'selected' : ''; ?>>All Events</option>
                        <?php
                        foreach ($event_names as $key => $event_name) {
                            echo "<option value='" . htmlspecialchars($event_ids[$key]) . "' " . ($selected_event == $event_ids[$key] ? 'selected' : '') . ">" . htmlspecialchars($event_name) . "</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="card-container">
                    <div class="card">
                        <h2>Event Statistics</h2>
                        <p id="total-events">Total Events: <?php echo count($event_names); ?></p>
                    </div>
                    <div class="card">
                        <h2>Respondents</h2>
                        <p id="total-respondents">Total Respondents: <?php echo $total_respondents; ?></p>
                    </div>
                    <div class="card">
                        <h2>Feedback Submissions</h2>
                        <p>Total Feedback Users: <?php echo $total_feedback_users; ?></p>
                    </div>

                    <div class="card">
                        <h2>Average Feedback Rating</h2>
                        <p>4.5/5</p>
                    </div>
                </div>

                <div class="chart-container">
                    <canvas id="barChart"></canvas>
                </div>

                <div class="chart-container">
                    <canvas id="pieChart"></canvas>
                </div>
            </div>
            <div class="table-container">
            <h2>Questions and Answers</h2>
<table class="styled-table">
    <thead>
        <tr>
            <th>Question</th>
            <th>Question Type</th>
            <th>Answers</th>
            <th>Number of Users</th>
        </tr>
    </thead>
    <tbody>
    <?php
    if (!empty($questions_data)) {
        foreach ($questions_data as $question) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($question['question_text']) . "</td>";
            echo "<td>" . htmlspecialchars($question['question_type']) . "</td>";

            // Loop over the answers and display each one with its count
            echo "<td>";
            foreach ($question['answers'] as $answer) {
                echo htmlspecialchars($answer['option_text']) . "<br>"; // Answer text
            }
            echo "</td>";

            // Display the number of users for each answer
            echo "<td>";
            foreach ($question['answers'] as $answer) {
                echo $answer['num_selected'] . "<br>"; // Number of users who selected the answer
            }
            echo "</td>";

            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='4'>No questions available for this event.</td></tr>";
    }
    ?>
    </tbody>
</table>

    </table>
            </div>
        </main>


    </div>


    <div class="container-main">
        <button id="chatbot-toggler">
            <span><img src='style/Images/chatlogo.png' style="height: 30px;"></span>
            <span class="material-symbols-rounded">close</span>
        </button>

        <div class="chatbot-popup">
            <div class="chat-header">
                <div class="header-info">
                    <img class="chatbot-logo" src="style/Images/chatbot.png" width="50" height="50" alt="Chatbot Logo">
                    <h2 class="logo-text">Evalus Chatbot</h2>
                </div>
                <button id="close-chatbot" class="material-symbols-rounded">keyboard_arrow_down</button>
            </div>
            <div class="chat-body">
                <div class="message bot-message">
                    <img class="chatbot-logo" src="style/Images/chatbot-black.png" width="35" height="35" alt="Chatbot Logo">
                    <div class="message-text"> Hello there! I'm Evalus. <br /> What can I assist you with today? I'm here to help! </div>
                </div>
            </div>
            <div class="chat-footer">
                <form action="#" class="chat-form">
                    <textarea placeholder="Message..." class="message-input" required></textarea>
                    <div class="chat-controls">
                        <button type="button" id="emoji-picker" class="material-symbols-outlined">sentiment_satisfied</button>
                        <div class="file-upload-wrapper">
                            <input type="file" accept="image/*" id="file-input" hidden />
                            <button type="button" id="file-upload" class="material-symbols-rounded">attach_file</button>
                            <button type="button" id="file-cancel" class="material-symbols-rounded">close</button>
                        </div>
                        <button type="submit" id="send-message" class="material-symbols-rounded">arrow_upward</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", () => {
            const barCtx = document.getElementById('barChart').getContext('2d');
            const pieCtx = document.getElementById('pieChart').getContext('2d');

            const eventNames = <?php echo json_encode($event_names); ?>;
            const respondentsData = <?php echo json_encode($respondents_count); ?>;
            const totalEvents = <?php echo $total_events; ?>;

            const eventSelect = document.getElementById('event-select');
            const totalEventsElement = document.getElementById('total-events');

            // Update charts
            new Chart(barCtx, {
                type: 'bar',
                data: {
                    labels: eventNames,
                    datasets: [{
                        label: 'Monthly Respondents',
                        data: respondentsData,
                        backgroundColor: [
                            'rgba(236, 29, 39, 0.3)',
                            'rgba(29, 120, 236, 0.3)',
                            'rgba(120, 236, 29, 0.3)',
                            'rgba(236, 166, 29, 0.3)',
                            'rgba(95, 95, 95, 0.3)'
                        ],
                        borderColor: [
                            '#EC1D27',
                            '#1D78EC',
                            '#78EC1D',
                            '#ECA61D',
                            '#5F5F5F'
                        ],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Number of Respondents in Evaluation Forms'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                stepSize: 1,
                            }
                        }
                    }
                }
            });

            new Chart(pieCtx, {
                type: 'pie',
                data: {
                    labels: eventNames,
                    datasets: [{
                        label: 'Respondents by Event',
                        data: respondentsData,
                        backgroundColor: [
                            'rgba(236, 29, 39, 0.3)',
                            'rgba(29, 120, 236, 0.3)',
                            'rgba(120, 236, 29, 0.3)',
                            'rgba(236, 166, 29, 0.3)',
                            'rgba(95, 95, 95, 0.3)'
                        ],
                        borderColor: [
                            '#EC1D27',
                            '#1D78EC',
                            '#78EC1D',
                            '#ECA61D',
                            '#5F5F5F'
                        ],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Number of Respondents'
                        }
                    }
                }
            });

        });
    </script>
    <script>
function updateRespondents() {
    const selectedEvent = document.getElementById('event-select').value;
    window.location.href = window.location.pathname + "?event=" + selectedEvent;
}

    </script>
    <script src="https://cdn.jsdelivr.net/npm/emoji-mart@latest/dist/browser.js"></script>
    <script src="chatbot/chatbot.js"></script>
    <script src="navbar/navmover.js"></script>

</body>

</html>