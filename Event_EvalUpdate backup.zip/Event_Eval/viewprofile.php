<?php
include('database.php');
session_start();


$userId = $_SESSION['user_id'] ?? null;


// Redirect to login page if user is not logged in
if (!$userId) {
    header("Location: login.php");
    exit();
}


function getFeedback($userId) {
    global $conn;
    $query = "
        SELECT
            e.event_name,
            e.department,
            f.status
        FROM feedback f
        JOIN events e ON f.event_id = e.id
        WHERE f.user_id = ?
    ";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}


// Fetch user profile data
function getProfile($userId) {
    global $conn;
    $query = "
        SELECT
            r.firstName,
            r.lastName,
            r.department,
            CONCAT(r.firstName, ' ', r.lastName) AS username,
            IFNULL(p.profilePicture, 'uploads/Default.jpg') AS profilePicture,
            p.address,
            p.emergency_contact,
            p.blood_type,
            p.campus_address
        FROM register r
        LEFT JOIN User_Profile p ON r.id = p.userId
        WHERE r.id = ?
    ";  
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc() ?: [
        'username' => '',
        'department' => '',
        'profilePicture' => 'uploads/Default.jpg',
        'address' => '',
        'emergency_contact' => '',
        'blood_type' => '',
        'campus_address' => ''
    ];
}


$profile = getProfile($userId);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <script src="navbar/Navloader.js" defer></script>
    <link rel="stylesheet" href="style/userprofile.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="style/viewprofile.css">
</head>
<body>
<div id="navbar"></div>
<div class="navbarmargin" style="margin-top:88px; margin-left: 260px;">
    <main>
        <h1 style="color: #EC1D27; margin: 10px;">Profile</h1>  
        <div class="profile-header">
        <div style="display: flex; align-items: center; gap: 15px;">
            <img src="<?php echo $profile['profilePicture']; ?>" alt="Profile Picture">
            <div>
                <h2><?php echo htmlspecialchars($profile['username']); ?></h2>
                <h3><?php echo htmlspecialchars($profile['department']); ?></h3>
            </div>
        </div>
        <a href="userprofile.php" class="btn-edit">Edit Profile</a>
    </div>
    <div class="profile-details">
        <div class="details-left">
<div class="feedback-section">
    <!-- About Section -->
    <div class="feedback-card">
        <h3>About</h3>
        <table class="feedback-table">
            <tbody>
                <tr>
                    <th>Address</th>
                    <td><?php echo htmlspecialchars($profile['address']); ?></td>
                </tr>
                <tr>
                    <th>Emergency Contact</th>
                    <td><?php echo htmlspecialchars($profile['emergency_contact']); ?></td>
                </tr>
                <tr>
                    <th>Blood Type</th>
                    <td><?php echo htmlspecialchars($profile['blood_type']); ?></td>
                </tr>
                <tr>
                    <th>Campus Address</th>
                    <td><?php echo htmlspecialchars($profile['campus_address']); ?></td>
                </tr>
            </tbody>
        </table>
    </div>


    <!-- History Section -->
    <div class="feedback-card">
    <h3>History of Evaluated Events</h3>
    <table class="feedback-table">
        <thead>
            <tr>
                <th>Event Name</th>
                <th>Department</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $historyEvents = getFeedback($userId); // Fetch feedback history for the logged-in user
            ?>
            <?php if (empty($historyEvents)): ?>
                <tr>
                    <td colspan="3">No history found</td>
                </tr>
            <?php else: ?>
                <?php foreach ($historyEvents as $event): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($event['event_name']); ?></td>
                        <td><?php echo htmlspecialchars($event['department']); ?></td>
                        <td>
                            <?php
                            echo $event['status'] === 'answered' ? '✘' : '✔';
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</div>
</div>
<div class="slide-pic">
<h3>BATANGAS STATE UNIVERSITY-TNEU JPLPC MALVAR</h3>
<table class="slide-pic">
                <!-- Right Column: Slideshow -->
            <div class="slideshow-container">
                <div class="slide active">
                    <img src="style/Images/malvar-slider.jpg" alt="Slide 1">
                </div>
                <div class="slide">
                    <img src="style/Images/cicsbuilding.png" alt="Slide 2">
                </div>
                <div class="slide">
                    <img src="style/Images/CIT.jpg" alt="Slide 3">
                </div>
                <div class="slide">
                    <img src="style/Images/batstateu-banner.png" alt="Slide 4">
                </div>


                <button class="prev">&#10094;</button>
                <button class="next">&#10095;</button>


                <div class="dot-container">
                    <span class="dot active"></span>
                    <span class="dot"></span>
                    <span class="dot"></span>
                    <span class="dot"></span>
                </div>
        </div>
    </main>
</div>


   
    <script>
        let slideIndex = 0; // Initialize slide index
    const slides = document.querySelectorAll('.slide'); // Select all slides
    const dots = document.querySelectorAll('.dot'); // Select all dots


    function showSlides(n) {
        // Loop back to the first slide if needed
        slideIndex = (n + slides.length) % slides.length;


        // Hide all slides and deactivate all dots
        slides.forEach((slide) => slide.classList.remove('active'));
        dots.forEach((dot) => dot.classList.remove('active'));


        // Show the current slide and activate the corresponding dot
        slides[slideIndex].classList.add('active');
        dots[slideIndex].classList.add('active');
    }


    // Automatically change slide every 3 seconds
    setInterval(() => showSlides(slideIndex + 1), 3000);


    // Manual navigation using dots
    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => showSlides(index));
    });


    // Manual navigation using buttons
    document.querySelector('.prev').addEventListener('click', () => showSlides(slideIndex - 1));
    document.querySelector('.next').addEventListener('click', () => showSlides(slideIndex + 1));
    </script>
</body>
</html>
