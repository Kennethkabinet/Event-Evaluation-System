<?php
include('database.php');

// Fetch feedback data from the database
$sql = "SELECT feedback.id, 
               CONCAT(register.firstName, ' ', register.lastName) AS name, 
               register.email, 
               feedback.experience_rating, 
               feedback.submitted_at, 
               feedback.comments 
        FROM feedback 
        JOIN register ON feedback.user_id = register.id 
        JOIN events ON feedback.event_id = events.id";

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Access</title>
    <script src="navbar/AdminNavloader.js" defer></script>
    <link rel="stylesheet" href="style/viewfeed.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="chatbot/chatbot.css">
    <link rel="stylesheet" href="style/table.css">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght@400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:wght@400&display=swap" rel="stylesheet">
    <style>
        .modal-title {
            text-align: center;
            color: var(--red-color);

        }

        /* Updated Popup Modal style */
        .popup-outer {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }

        .popup-box {
            position: relative;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            max-width: 500px;
            width: 80%;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 1.2rem;
            color: #333;
            margin-bottom: 10px;
        }

        .close {
            font-size: 1.5rem;
            cursor: pointer;
            color: #e74c3c;
        }

        .modal-content {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .modal-content p {
            margin: 0;
            font-size: 1rem;
            color: #555;
        }

        .modal-content span {
            font-weight: bold;
        }

        #feedback-comments {
            width: 100%;
            height: 150px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            resize: vertical;
        }

        .modal-btn {
            background-color: var(--red-color);
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            align-self: flex-end;
            float: right;
        }

        .modal-btn:hover {
            background-color: #c0392b;
        }

        .feedback-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
        }

        .feedback-header p {
            margin: 0;
            font-size: 1rem;
            color: #333;
        }
    </style>
</head>

<body>
    <div id="adminbar"></div>
    <div class="navbarmargin" style="margin-top:88px">
        <main>
            <h1 style="padding: 30px;">View Feedback</h1>
            <div class="table-container">
                <table class="styled-table">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Ratings</th>
                            <th>Submitted at</th>
                            <th>Feedback</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo '<tr>
                                        <td>' . htmlspecialchars($row['name']) . '</td>
                                        <td>' . htmlspecialchars($row['email']) . '</td>
                                        <td>' . htmlspecialchars($row['experience_rating']) . '</td>
                                        <td>' . htmlspecialchars($row['submitted_at']) . '</td>
                                        <td><button class="view-feedback-btn" data-feedback="' . htmlspecialchars($row['comments']) . '" style="background-color: #b3e6cc; color: #006622; border: 1px solid #006622; padding: 5px 15px; border-radius: 5px; cursor: pointer;">View</button></td>
                                      </tr>';
                            }
                        } else {
                            echo '<tr><td colspan="5">No feedback found</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>


    <div class="popup-outer" id="feedback-modal">
        <div class="popup-box">
            <i id="close-modal" class="bx bx-x close"></i>
            <div class="modal-content">

                <h2 class="modal-title">Feedback</h2>


                <div class="feedback-header">
                    <p><strong>From:</strong> <span id="feedback-name" style="color: var(--red-color);"></span></p>
                    <p><strong>Date:</strong> <span id="feedback-date" style="color: var(--red-color);"></span></p>
                </div>

                <textarea id="feedback-comments" readonly></textarea>

                <button id="close-modal-btn" class="modal-btn">Okay</button>
            </div>
        </div>
    </div>

    <div class="container-main">

        <button id="chatbot-toggler">
        <span><img src='style/Images/chatlogo.png' style="height: 30px;"></span>
            <span class="material-symbols-rounded">close</span>
        </button>

        <div class="chatbot-popup">
            <div class="chat-header">
                <div class="header-info">
                    <img class="chatbot-logo" src="style/Images/chatbot.png" width="50" height="50" alt="Chatbot Logo">
                    <h2 class="logo-text">Evalus Chatbot</h2>
                </div>
                <button id="close-chatbot" class="material-symbols-rounded">keyboard_arrow_down</button>
            </div>

            <div class="chat-body">
                <div class="message bot-message">
                    <img class="chatbot-logo" src="style/Images/chatbot-black.png" width="35" height="35" alt="Chatbot Logo">
                    <div class="message-text"> Hello there! I'm Evalus. <br /> What can I assist you with today? I'm here to help! </div>
                </div>
            </div>

            <div class="chat-footer">
                <form action="#" class="chat-form">
                    <textarea placeholder="Message..." class="message-input" required></textarea>
                    <div class="chat-controls">
                        <button type="button" id="emoji-picker" class="material-symbols-outlined">sentiment_satisfied</button>
                        <div class="file-upload-wrapper">
                            <input type="file" accept="image/*" id="file-input" hidden />
                            <img src="#" />
                            <button type="button" id="file-upload" class="material-symbols-rounded">attach_file</button>
                            <button type="button" id="file-cancel" class="material-symbols-rounded">close</button>
                        </div>
                        <button type="submit" id="send-message" class="material-symbols-rounded">arrow_upward</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/emoji-mart@latest/dist/browser.js"></script>
    <script src="chatbot/chatbot.js"></script>
    <script src="navbar/navmover.js"></script>

    <script>
        const viewButtons = document.querySelectorAll('.view-feedback-btn');
        const feedbackModal = document.getElementById('feedback-modal');
        const closeModal = document.getElementById('close-modal');
        const closeModalBtn = document.getElementById('close-modal-btn');
        const feedbackName = document.getElementById('feedback-name');
        const feedbackDate = document.getElementById('feedback-date');
        const feedbackComments = document.getElementById('feedback-comments');

        viewButtons.forEach(button => {
            button.addEventListener('click', function() {
                const comments = button.getAttribute('data-feedback');
                const name = button.closest('tr').querySelector('td:first-child').textContent;
                const date = button.closest('tr').querySelector('td:nth-child(4)').textContent;

                feedbackName.textContent = name;
                feedbackDate.textContent = date;
                feedbackComments.textContent = comments;

                feedbackModal.style.display = 'flex';
            });
        });

        closeModal.addEventListener('click', function() {
            feedbackModal.style.display = 'none';
        });

        closeModalBtn.addEventListener('click', function() {
            feedbackModal.style.display = 'none';
        });
    </script>
</body>

</html>

<?php

mysqli_close($conn);
?>