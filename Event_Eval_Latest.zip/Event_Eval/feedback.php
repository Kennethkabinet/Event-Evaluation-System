<?php
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>
    <script src="navbar/Navloader.js" defer></script>
    <link rel="stylesheet" href="style/feedback.css">
    <link rel="stylesheet" href="style/table.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=arrow_forward" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <style>
        .header-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 20px;
        }

        .header-container h2 {
            margin: 0;
        }

        .header-container label,
        .header-container select {
            margin-left: 10px;
        }

        #dropdown {
            font-family: Arial, sans-serif;
            font-size: 18px;
            color: #4a4a4a;
            border: 1px solid #4a4a4a;
            border-radius: 10px;
            background: transparent;
            cursor: pointer;
            padding: 5px;
            appearance: none;
            outline: none;
            margin-right: 20px;
        }

        #dropdown::after {
            content: " ▼";
            font-size: 12px;
            color: #4a4a4a;
        }

        label {
            font-family: Arial, sans-serif;
            font-size: 18px;
            font-weight: 400;
            color: #b2b2b2;
        }

        label span {
            font-weight: bold;
            color: #000;
        }
    </style>
</head>

<body>
    <div id="navbar"></div>
    <div class="navbarmargin" style="margin-top:88px">
        <main>
            <h1 style="padding: 30px;">Upcoming Events</h1>
            <div class="header-container">
                <h2>All Evaluated Events</h2>
                <div>
                    <label for="dropdown">Sort by: </label>
                    <select id="dropdown" name="dropdown">
                        <option value="option1">Latest</option>
                        <option value="option2">Oldest</option>
                    </select>
                </div>
            </div>
            <div class="table-container" >
                <table class="styled-table">
                    <thead>
                        <tr>
                            <th>Event Name</th>
                            <th>Department</th>
                            <th>Date</th>
                            <th>Create Feedback</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Kita Kita</td>
                            <td>CICS</td>
                            <td>19/11/2024</td>
                            <td><button style="background-color: #b3e6cc; color: #006622; border: 1px solid #006622; padding: 5px 15px; border-radius: 5px; cursor: pointer;">Evaluate</button></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </main>
        <script src="navbar/navmover.js"></script>
</body>

</html>