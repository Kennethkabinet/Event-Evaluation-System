<?php
include('database.php');
session_start();


$userId = $_SESSION['user_id'] ?? null;


// Redirect to login page if user is not logged in
if (!$userId) {
    header("Location: login.php");
    exit();
}


// Fetch user profile data
function getProfile($userId) {
    global $conn;
    $query = "
        SELECT
            r.firstName,
            r.lastName,
            r.department,
            CONCAT(r.firstName, ' ', r.lastName) AS username,
            IFNULL(p.profilePicture, 'uploads/Default.jpg') AS profilePicture,
            p.address,
            p.emergency_contact,
            p.blood_type,
            p.campus_address
        FROM register r
        LEFT JOIN User_Profile p ON r.id = p.userId
        WHERE r.id = ?
    ";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc() ?: [
        'username' => '',
        'department' => '',
        'profilePicture' => 'uploads/Default.jpg',
        'address' => '',
        'emergency_contact' => '',
        'blood_type' => '',
        'campus_address' => ''
    ];
}


$profile = getProfile($userId);
?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <script src="navbar/Navloader.js" defer></script>
    <link rel="stylesheet" href="style/userprofile.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="style/viewprofile.css">
       
</head>
<body>
<div id="navbar"></div>
<div class="navbarmargin" style="margin-top:88px; margin-left: 260px;">
    <main>
        <h1 style="color: #EC1D27; margin: 10px;">Profile</h1>  
        <div class="profile-header">
        <div style="display: flex; align-items: center; gap: 15px;">
            <img src="<?php echo $profile['profilePicture']; ?>" alt="Profile Picture">
            <div>
                <h2><?php echo htmlspecialchars($profile['username']); ?></h2>
                <h3><?php echo htmlspecialchars($profile['department']); ?></h3>
            </div>
        </div>
        <a href="userprofile.php" class="btn-edit">Edit Profile</a>
    </div>
    <div class="profile-details">
        <div class="details-left">
            <h3>About</h3>
            <div>
            <label for="address">Address:</label>
            <input type="text" id="address" name="address" value="<?php echo htmlspecialchars($profile['address']); ?>" readonly>
        </div>
        <div>
            <label for="emergency_contact">Emergency Contact:</label>
            <input type="text" id="emergency_contact" name="emergency_contact" value="<?php echo htmlspecialchars($profile['emergency_contact']); ?>" readonly>
        </div>
        <div>
            <label for="blood_type">Blood Type:</label>
            <input type="text" id="blood_type" name="blood_type" value="<?php echo htmlspecialchars($profile['blood_type']); ?>" readonly>
        </div>
        <div>
            <label for="campus_address">Campus Address:</label>
            <input type="text" id="campus_address" name="campus_address" value="<?php echo htmlspecialchars($profile['campus_address']); ?>" readonly>
        </div>
        <div class="slide-picture">Slide Picture</div>
    </div>
</body>
</html>


