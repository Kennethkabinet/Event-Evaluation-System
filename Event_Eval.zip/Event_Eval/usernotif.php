<?php
?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>
    <script src="navbar/Navloader.js" defer></script>
    <link rel="stylesheet" href="style/usernotif.css"> 
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=arrow_forward" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
</head>

<body>
    <div id="navbar"></div>
    <div class="navbarmargin" style="margin-top:88px">
        <main>
            <h1 style="padding: 30px;">Notification</h1>
            
    <div class="notification-table">
        <div class="header">
            <h2>Unread Notification</h2>
            <button class="delete-all">Delete All</button>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Notification Type</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Evaluated Event</td>
                    <td>
                        <img src="style/Images/mail-icon.png" alt="Mail Icon"> CABEIHM
                    </td>
                </tr>
                <tr>
                    <td>Evaluated Event</td>
                    <td>
                        <img src="style/Images/mail-icon.png"  alt="Mail Icon"> CICS
                    </td>
                </tr>
                <tr>
                    <td>Open for Evaluation</td>
                    <td>
                        <img src="style/Images/mail-icon.png"  alt="Mail Icon"> Kita Kita
                    </td>
                </tr>
                <tr>
                    <td>Open for Evaluation</td>
                    <td>
                        <img src="style/Images/mail-icon.png"  alt="Mail Icon"> Intrams 2024
                    </td>
                </tr>
                <tr>
                    <td>Open for Evaluation</td>
                    <td>
                        <img src="style/Images/mail-icon.png"  alt="Mail Icon"> CIT
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="notification-table">
        <h2>Viewed Notification</h2>
        <table>
            <thead>
                <tr>
                    <th>Notification Type</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Evaluated Event</td>
                    <td>
                        <img src="style/Images/mail-icon.png" alt="Mail Icon"> CIT
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
            </div>
        </main>
        <script src="navbar/navmover.js"></script>
</body>

</html>
