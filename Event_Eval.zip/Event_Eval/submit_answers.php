<?php
include('database.php');
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id']; 
    } else {
        header("Location: login.php");
        exit();
    }

    $event_id = $_POST['event_id'];
    $responses = [];


    foreach ($_POST as $key => $value) {
        if (strpos($key, 'question_') === 0) {
            $question_id = str_replace('question_', '', $key);
            $responses[] = [
                'question_id' => $question_id,
                'answer' => $value
            ];
        }
    }


    foreach ($responses as $response) {
        $stmt = $conn->prepare("
            INSERT INTO question_answers (event_id, question_id, user_id, answer, status) 
            VALUES (?, ?, ?, ?, 'completed')
            ON DUPLICATE KEY UPDATE answer = VALUES(answer), status = 'completed'
        ");
        $stmt->bind_param("iiis", $event_id, $response['question_id'], $user_id, $response['answer']);
        $stmt->execute();
    }
    


    $stmt = $conn->prepare("
        SELECT COUNT(*) AS total_questions 
        FROM questions 
        WHERE event_id = ?
    ");
    $stmt->bind_param("i", $event_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $total_questions = $result['total_questions'];


    $stmt = $conn->prepare("
        SELECT COUNT(*) AS answered_questions 
        FROM question_answers 
        WHERE event_id = ? AND user_id = ?
    ");
    $stmt->bind_param("ii", $event_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $answered_questions = $result['answered_questions'];

    if ($answered_questions < $total_questions) {
        $stmt = $conn->prepare("
            UPDATE question_answers 
            SET status = 'pending' 
            WHERE event_id = ? AND user_id = ?
        ");
        $stmt->bind_param("ii", $event_id, $user_id);
        $stmt->execute();
    } else {
        $stmt = $conn->prepare("
            UPDATE question_answers 
            SET status = 'completed' 
            WHERE event_id = ? AND user_id = ?
        ");
        $stmt->bind_param("ii", $event_id, $user_id);
        $stmt->execute();
    }

    header("Location: question.php");
    exit();
}
?>
