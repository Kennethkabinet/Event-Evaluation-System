<?php
// Include the database connection
include('database.php');

// Fetch event data
$sql = "SELECT id, event_name, department, event_date FROM events";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evaluate</title>
    <script src="navbar/Navloader.js" defer></script>
    <link rel="stylesheet" href="style/questions.css">
    <link rel="stylesheet" href="style/table.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=arrow_forward" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
</head>

<body>
    <div id="navbar"></div>
    <div class="navbarmargin" style="margin-top:88px">
        <main>
            <h1 style="padding: 30px;">Evaluate Events</h1>
            <div class="table-container">
                <table class="styled-table">
                    <thead>
                        <tr>
                            <th>Event Name</th>
                            <th>Department</th>
                            <th>Date</th>
                            <th>Evaluate Forms</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result->num_rows > 0) {

                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                        <td>" . $row["event_name"] . "</td>
                                        <td>" . $row["department"] . "</td>
                                        <td>" . $row["event_date"] . "</td>
                                        <td>
                                            <button class='evaluate-btn' data-event-id='" . $row["id"] . "' style='background-color: #b3e6cc; color: #006622; border: 1px solid #006622; padding: 5px 15px; border-radius: 5px; cursor: pointer;'>
                                               Answer
                                            </button>
                                        </td>
                                      </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='4'>No events found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </main>

        <section class="popup-outer">
            <div class="popup-box">
                <i id="close" class='bx bx-x close'></i>
                <div class="text" style="text-align: center;">
                    <span class="create-feedback">Create Feedback</span>
                </div>
                <form>
                    <input type="hidden" name="event_id" value="">

                    <div class="question-container">
                        <!-- Dynamic Questions -->
                    </div>
                    <div class="button">
                        <button type="button" id="cancel" class="cancel">Cancel</button>
                        <button type="submit" class="send">Submit</button>
                    </div>
                </form>
            </div>
        </section>

        <script>
            const popupOuter = document.querySelector('.popup-outer');
            const closeBtns = document.querySelectorAll('.close, #cancel');
            const evaluateBtns = document.querySelectorAll('.evaluate-btn');

            evaluateBtns.forEach(button => {
                button.addEventListener('click', (e) => {
                    e.preventDefault();

                    // Get the event_id dynamically from the clicked button
                    const event_id = button.getAttribute('data-event-id');


                    document.querySelector('input[name="event_id"]').value = event_id;

                    loadQuestions(event_id);

                    popupOuter.classList.add('active');
                });
            });

            closeBtns.forEach(btn => {
                btn.addEventListener('click', () => {
                    popupOuter.classList.remove('active'); 
                });
            });


            function loadQuestions(event_id) {
                const modalContent = document.querySelector('.popup-box .question-container'); 

                // AJAX Request
                const xhr = new XMLHttpRequest();
                xhr.open("GET", "load_questions.php?event_id=" + event_id, true);
                xhr.onload = function() {
                    if (xhr.status == 200) {

                        const questions = JSON.parse(xhr.responseText);

                        modalContent.innerHTML = "";

                        questions.forEach((question, index) => {
                            modalContent.innerHTML += `
                    <div>
                        <label>Q${index + 1}: ${question.question_text}</label>
                        <input type="text" name="question_${question.id}" />
                    </div>
                `;
                        });
                    } else {
                        console.error('Failed to fetch questions');
                    }
                };
                xhr.send();
            }
        </script>
            <script src="chatbot/chatbot.js"></script>
            <script src="navbar/navmover.js"></script>
    </div>
</body>

</html>