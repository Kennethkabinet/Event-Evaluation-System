<?php

include('database.php');

$sql = "SELECT e.event_name, COUNT(f.user_id) AS num_respondents 
        FROM events e 
        LEFT JOIN feedback f ON e.id = f.event_id 
        GROUP BY e.id";
$result = $conn->query($sql);

// Fetch event names and number of respondents into arrays
$event_names = [];
$respondents_count = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $event_names[] = $row['event_name'];
        $respondents_count[] = $row['num_respondents'];
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports</title>
    <script src="navbar/AdminNavloader.js" defer></script>
    <link rel="stylesheet" href="style/table.css">
    <link rel="stylesheet" href="style/reports.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="chatbot/chatbot.css">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght@400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:wght@400&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .chart-container {
            width: 45%;
            height: 400px;
            margin-bottom: 50px;
            margin-top: 50px;
        }

        .chart-wrapper {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin: 100px;
            margin-bottom: 0px;
            margin-top: 0px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }
    </style>
</head>

<body>
    <div id="adminbar"></div>
    <div class="navbarmargin" style="margin-top:88px">
        <main>
            <h1 style="padding: 30px;">Reports</h1>
            <div class="chart-wrapper">
                <div class="chart-container">
                    <canvas id="barChart"></canvas>
                </div>
                <div class="chart-container">
                    <canvas id="pieChart"></canvas>
                </div>
            </div>

            <div class="table-container">
                <table class="styled-table">
                    <thead>
                        <tr>
                            <th>Event Created</th>
                            <th>Department</th>
                            <th># of Respondents</th>
                            <th>Date</th>
                            <th>Average Rating</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Kita Kita</td>
                            <td>CICS</td>
                            <td>5</td>
                            <td>19/11/2024</td>
                            <td>5</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    <div class="container-main">
        <button id="chatbot-toggler">
        <span><img src='style/Images/chatlogo.png' style="height: 30px;"></span>
            <span class="material-symbols-rounded">close</span>
        </button>

        <div class="chatbot-popup">
            <div class="chat-header">
                <div class="header-info">
                    <img class="chatbot-logo" src="style/Images/chatbot.png" width="50" height="50" alt="Chatbot Logo">
                    <h2 class="logo-text">Evalus Chatbot</h2>
                </div>
                <button id="close-chatbot" class="material-symbols-rounded">keyboard_arrow_down</button>
            </div>
            <div class="chat-body">
                <div class="message bot-message">
                    <img class="chatbot-logo" src="style/Images/chatbot-black.png" width="35" height="35" alt="Chatbot Logo">
                    <div class="message-text"> Hello there! I'm Evalus. <br /> What can I assist you with today? I'm here to help! </div>
                </div>
            </div>
            <div class="chat-footer">
                <form action="#" class="chat-form">
                    <textarea placeholder="Message..." class="message-input" required></textarea>
                    <div class="chat-controls">
                        <button type="button" id="emoji-picker" class="material-symbols-outlined">sentiment_satisfied</button>
                        <div class="file-upload-wrapper">
                            <input type="file" accept="image/*" id="file-input" hidden />
                            <button type="button" id="file-upload" class="material-symbols-rounded">attach_file</button>
                            <button type="button" id="file-cancel" class="material-symbols-rounded">close</button>
                        </div>
                        <button type="submit" id="send-message" class="material-symbols-rounded">arrow_upward</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
  document.addEventListener("DOMContentLoaded", () => {
    const barCtx = document.getElementById('barChart').getContext('2d');
    const pieCtx = document.getElementById('pieChart').getContext('2d');

    const eventNames = <?php echo json_encode($event_names); ?>;
    const respondentsData = <?php echo json_encode($respondents_count); ?>;

    new Chart(barCtx, {
        type: 'bar',
        data: {
            labels: eventNames, 
            datasets: [{
                label: 'Monthly Respondents',
                data: respondentsData, 
                backgroundColor: [
                    'rgba(236, 29, 39, 0.3)',
                    'rgba(29, 120, 236, 0.3)',
                    'rgba(120, 236, 29, 0.3)',
                    'rgba(236, 166, 29, 0.3)',
                    'rgba(95, 95, 95, 0.3)'
                ],
                borderColor: [
                    '#EC1D27',
                    '#1D78EC',
                    '#78EC1D',
                    '#ECA61D',
                    '#5F5F5F'
                ],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Number of Respondents in Evaluation Forms'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    new Chart(pieCtx, {
        type: 'pie',
        data: {
            labels: eventNames, 
            datasets: [{
                label: 'Respondents by Event',
                data: respondentsData, 
                backgroundColor: [
                    'rgba(236, 29, 39, 0.3)',
                    'rgba(29, 120, 236, 0.3)',
                    'rgba(120, 236, 29, 0.3)',
                    'rgba(236, 166, 29, 0.3)',
                    'rgba(95, 95, 95, 0.3)'
                ],
                borderColor: [
                    '#EC1D27',
                    '#1D78EC',
                    '#78EC1D',
                    '#ECA61D',
                    '#5F5F5F'
                ],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Number of Respondents'
                }
            }
        }
    });
});

</script>

    <script src="https://cdn.jsdelivr.net/npm/emoji-mart@latest/dist/browser.js"></script>
    <script src="chatbot/chatbot.js"></script>
    <script src="navbar/navmover.js"></script>
    
</body>

</html>
