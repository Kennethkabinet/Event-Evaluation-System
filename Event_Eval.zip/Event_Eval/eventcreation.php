<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Creation</title>
    <script src="navbar/AdminNavloader.js" defer></script>
    <link rel="stylesheet" href="style/eventcreation.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="chatbot/chatbot.css">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght@400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:wght@400&display=swap" rel="stylesheet">
</head>



<body>
    <div id="adminbar"></div>
    <div class="navbarmargin" style="margin-top:88px">
        <main>
            <h1 style="padding: 30px;">Event Creation Evaluation Form</h1>
            <br>
            <br>

            <form action="save_event.php" method="POST" enctype="multipart/form-data">
                <div class="container">
                    <div class="head-form">
                        <h2>Form Name</h2>
                        <div class="input-group">
                            <input type="text" name="form_name" placeholder="Untitled Form" required>
                            <input type="submit" value="Deploy">
                        </div>
                    </div>

                    <h2>Event Information:</h2>
                    <hr style="width: 860px; margin: 20px auto;">
                    <br>
                    <div class="form-description">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="departmentinfo">Department:</label>
                                <input type="text" name="departmentinfo" id="departmentinfo" required>
                            </div>
                            <div class="form-group">
                                <label for="dateinfo">Date:</label>
                                <input type="date" name="dateinfo" id="dateinfo" required>
                            </div>
                        </div>

                        <div class="form-group description">
                            <label for="descriptioninfo">Description:</label>
                            <textarea name="descriptioninfo" id="descriptioninfo" rows="4" placeholder="Add your short description" required></textarea>
                        </div>
                    </div>

                    <h2>Evaluation Questions:</h2>
                    <div class="form-question">
                        <!-- New question group ay papasok dine -->
                    </div>

                    <div class="add-question">
                        <button type="button"><i class="fas fa-plus"></i> Add New Question</button>
                    </div>
                </div>
            </form>
        </main>
        <div class="container-main">
            <!--Toggler -->
            <button id="chatbot-toggler">
                <span class="material-symbols-rounded">mode_comment</span>
                <span class="material-symbols-rounded">close</span>
            </button>

            <div class="chatbot-popup">
                <div class="chat-header">
                    <div class="header-info">
                        <img class="chatbot-logo" src="style/Images/chatbot.png" width="50" height="50" alt="Chatbot Logo">
                        <h2 class="logo-text">Evalus Chatbot</h2>
                    </div>
                    <button id="close-chatbot" class="material-symbols-rounded">keyboard_arrow_down</button>
                </div>

                <!--Body -->
                <div class="chat-body">
                    <div class="message bot-message">
                        <img class="chatbot-logo" src="style/Images/chatbot-black.png" width="35" height="35" alt="Chatbot Logo">
                        <div class="message-text"> Hello there! I'm Evalus. <br /> What can I assist you with today? I'm here to help! </div>
                    </div>
                </div>

                <!--Footer -->
                <div class="chat-footer">
                    <form action="#" class="chat-form">
                        <textarea placeholder="Message..." class="message-input" required></textarea>
                        <div class="chat-controls">
                            <button type="button" id="emoji-picker" class="material-symbols-outlined">sentiment_satisfied</button>
                            <div class="file-upload-wrapper">
                                <input type="file" accept="image/*" id="file-input" hidden />
                                <img src="#" />
                                <button type="button" id="file-upload" class="material-symbols-rounded">attach_file</button>
                                <button type="button" id="file-cancel" class="material-symbols-rounded">close</button>
                            </div>
                            <button type="submit" id="send-message" class="material-symbols-rounded">arrow_upward</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
       
    </div>
    <script src="https://cdn.jsdelivr.net/npm/emoji-mart@latest/dist/browser.js"></script>
    <script src="chatbot/chatbot.js"></script>
    <script src="navbar/navmover.js"></script>
    <script src="scripts/eventcreation.js"></script>
</body>

</html>