<?php

include('database.php');

// Kumuha ng event_id msa URL
$event_id = $_GET['event_id'];

// Query para kunin ang mga questions para sa event_id
$sql = "SELECT id, question_text FROM questions WHERE event_id = ?";

// Anti SQL injection 
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $event_id); // I-bind ang event_id sa query
$stmt->execute(); // I-execute ang query
$result = $stmt->get_result(); // Kunin ang resulta

$questions = [];
while ($row = $result->fetch_assoc()) {
    $questions[] = $row; 
}

echo json_encode($questions);
?>
