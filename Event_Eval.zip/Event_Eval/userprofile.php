<!DOCTYPE html>
<html lang="en"> 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>
    <script src="navbar/Navloader.js" defer></script>
    <link rel="stylesheet" href="style/userprofile.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=arrow_forward" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
</head>
<body>
    <div id="navbar"></div>
    <div class="navbarmargin" style="margin-top:88px; margin-left: 260px;">
        <main>
            <h1 style="color: #EC1D27; padding: 10px;">Profile</h1>
            <h2 style="padding: 10px;">My Details</h2>
            <div class="profile-container">
                <div class="profile-header">
                    <img src="uploads/Defult.jpg" alt="Profile Picture">
                    <div>
                        <h2>Alice Guo</h2>
                        <h3>CICS</h3>
                    </div>
                    <div class="profile-buttons">
                        <form action="userprofile.php" method="POST" style="display: inline;">
                            <button name="upload" class="btn upload-btn">Upload New Photo</button>
                        </form>
                        <form action="userprofile.php" method="POST" style="display: inline;">
                            <button name="delete" class="btn delete-btn">Delete</button>
                        </form>
                    </div>
                </div>
                <div class="form-section">
                    <form>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="first_name">First Name</label>
                                <input type="text" name="first_name" id="first_name" value="First Name" required>
                            </div>
                            <div class="form-group">
                                <label for="last_name">Last Name</label>
                                <input type="text" name="last_name" id="last_name" value="Last Name" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group wide">
                                <label for="username">User Name</label>
                                <input type="text" name="username" id="username" value="User Name" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="email">Email Address</label>
                                <input type="email" name="email" id="email" value="Email Address" required>
                            </div>
                            <div class="form-group">
                                <label for="department">Department</label>
                                <input type="text" name="department" id="department" value="Department" required>
                            </div>
                        </div>
                        <div class="form-buttons">
                            <button type="submit" class="btn save-btn">Save</button>
                            <button type="reset" class="btn discard-btn">Discard</button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
        <script src="navbar/navmover.js"></script>
</body>
</html>
