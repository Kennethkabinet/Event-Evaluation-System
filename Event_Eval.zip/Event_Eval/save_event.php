<?php
include 'database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $event_name = mysqli_real_escape_string($conn, $_POST['form_name']);
    $department = mysqli_real_escape_string($conn, $_POST['departmentinfo']);
    $event_date = $_POST['dateinfo'];
    $description = mysqli_real_escape_string($conn, $_POST['descriptioninfo']);

    $upload_dir = 'uploads/';
    if (isset($_FILES['eventimage']) && $_FILES['eventimage']['error'] === 0) {
        $image_name = basename($_FILES['eventimage']['name']);
        $image_path = $upload_dir . $image_name;
        if (!move_uploaded_file($_FILES['eventimage']['tmp_name'], $image_path)) {
            echo "Image upload failed.";
        }
    }

    // Insert event data into the database
    $sql = "INSERT INTO events (event_name, department, event_date, description) 
            VALUES ('$event_name', '$department', '$event_date', '$description')";

    if (mysqli_query($conn, $sql)) {
        $event_id = mysqli_insert_id($conn);

        // Insert the notification with status 'unread'
        $sql_notification = "INSERT INTO notifications (event_id, status) 
                             VALUES ('$event_id', 'unread')";
        if (!mysqli_query($conn, $sql_notification)) {
            echo "Error inserting notification: " . mysqli_error($conn);
        }

        // Handle questions and options
        if (isset($_POST['questions']) && is_array($_POST['questions'])) {
            foreach ($_POST['questions'] as $question) {
                $question_text = mysqli_real_escape_string($conn, $question['text']);
                $question_type = mysqli_real_escape_string($conn, $question['type']);

                $sql_question = "INSERT INTO questions (event_id, question_text, question_type) 
                                 VALUES ('$event_id', '$question_text', '$question_type')";
                if (mysqli_query($conn, $sql_question)) {
                    $question_id = mysqli_insert_id($conn);

                    if ($question_type === 'multiplechoice' && isset($question['options']) && is_array($question['options'])) {
                        foreach ($question['options'] as $option) {
                            $option_text = mysqli_real_escape_string($conn, $option);
                            $sql_option = "INSERT INTO options (question_id, option_text) 
                                           VALUES ('$question_id', '$option_text')";
                            mysqli_query($conn, $sql_option);
                        }
                    }
                }
            }
        }

        // Redirect back to the event creation page
        header("Location: eventcreation.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>
