<?php
include 'database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve event data from the form
    $event_name = mysqli_real_escape_string($conn, $_POST['form_name']);
    $department = mysqli_real_escape_string($conn, $_POST['departmentinfo']);
    $event_date = $_POST['dateinfo'];
    $description = mysqli_real_escape_string($conn, $_POST['descriptioninfo']);

    // Image checker (upload image without saving to the database)
    $upload_dir = 'uploads/';
    if (isset($_FILES['eventimage']) && $_FILES['eventimage']['error'] === 0) {
        $image_name = basename($_FILES['eventimage']['name']);
        $image_path = $upload_dir . $image_name;

        // Move uploaded file to server
        if (!move_uploaded_file($_FILES['eventimage']['tmp_name'], $image_path)) {
            echo "Image upload failed.";
        }
    }

    // Insert event into the database (without the image path)
    $sql = "INSERT INTO events (event_name, department, event_date, description) 
            VALUES ('$event_name', '$department', '$event_date', '$description')";
    
    if (mysqli_query($conn, $sql)) {
        $event_id = mysqli_insert_id($conn); // Get the ID of the inserted event

        // Handle dynamic questions
        if (isset($_POST['questions']) && is_array($_POST['questions'])) {
            foreach ($_POST['questions'] as $question) {
                $question_text = mysqli_real_escape_string($conn, $question['text']);
                $question_type = mysqli_real_escape_string($conn, $question['type']);
                
                // Insert question into the database
                $sql_question = "INSERT INTO questions (event_id, question_text, question_type) 
                                 VALUES ('$event_id', '$question_text', '$question_type')";
                if (mysqli_query($conn, $sql_question)) {
                    $question_id = mysqli_insert_id($conn);

                    // Handle multiple choice options if the question is of that type
                    if ($question_type === 'multiplechoice' && isset($question['options']) && is_array($question['options'])) {
                        foreach ($question['options'] as $option) {
                            $option_text = mysqli_real_escape_string($conn, $option);
                            $sql_option = "INSERT INTO options (question_id, option_text) 
                                           VALUES ('$question_id', '$option_text')";
                            mysqli_query($conn, $sql_option);
                        }
                    }
                }
            }
        }

        // Redirect to the event creation page upon success
        header("Location: eventcreation.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}

// Close the database connection
mysqli_close($conn);
?>
