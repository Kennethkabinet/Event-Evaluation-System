    <?php
    include('database.php');

    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $event_id = $_POST['event_id'];
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $experience_rating = $_POST['experience'];
        $comments = mysqli_real_escape_string($conn, $_POST['comments']);

        // Insert feedback into the database
        $sql = "INSERT INTO feedback (event_id, name, email, experience_rating, comments) 
                VALUES ('$event_id', '$name', '$email', '$experience_rating', '$comments')";

        if (mysqli_query($conn, $sql)) {
            echo "Feedback submitted successfully!";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }

    // Fetch events from the database
    $sql = "SELECT event_name, department, event_date, id FROM events";
    $result = mysqli_query($conn, $sql);
    ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Events</title>
        <script src="navbar/Navloader.js" defer></script>
        <link rel="stylesheet" href="style/feedback.css">
        <link rel="stylesheet" href="style/table.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=arrow_forward" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    </head>

    <body>
        <div id="navbar"></div>
        <div class="navbarmargin" style="margin-top:88px">
            <main>
                <h1 style="padding: 30px;">Upcoming Events</h1>
                <div class="header-container">
                    <h2>All Evaluated Events</h2>
                    <div>
                        <label for="dropdown">Sort by: </label>
                        <select id="dropdown" name="dropdown">
                            <option value="option1">Latest</option>
                            <option value="option2">Oldest</option>
                        </select>
                    </div>
                </div>
                <div class="table-container">
                    <table class="styled-table">
                        <thead>
                            <tr>
                                <th>Event Name</th>
                                <th>Department</th>
                                <th>Date</th>
                                <th>Create Feedback</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if (mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo '<tr>
                                            <td>' . htmlspecialchars($row['event_name']) . '</td>
                                            <td>' . htmlspecialchars($row['department']) . '</td>
                                            <td>' . htmlspecialchars($row['event_date']) . '</td>
                                            <td><button class="evaluate-btn" data-event-id="' . $row['id'] . '" style="background-color: #b3e6cc; color: #006622; border: 1px solid #006622; padding: 5px 15px; border-radius: 5px; cursor: pointer;">Evaluate</button></td>
                                        </tr>';
                                }
                            } else {
                                echo '<tr><td colspan="4">No events found</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </main>

            <section class="popup-outer">
                <div class="popup-box">
                    <i id="close" class='bx bx-x close'></i>
                    <div class="text" style="text-align: center;">
                        <span class="create-feedback">Create Feedback</span>
                    </div>
                    <form method="POST" action="">
                        <input type="hidden" name="event_id" value="">
                        <label>Name</label>
                        <input type="text" name="name" placeholder="Enter your name" required>

                        <label>Email</label>
                        <input type="email" name="email" placeholder="Enter your email" required>

                        <label>Share your experience in scaling</label>

                        <div class="rating">
                            <div class="emoji-container">
                                <span class="emoji emoji-1">😣</span>
                                <span class="emoji emoji-2">😞</span>
                                <span class="emoji emoji-3">😐</span>
                                <span class="emoji emoji-4">😊</span>
                                <span class="emoji emoji-5">😍</span>
                            </div>
                            <div class="label-container">
                                <span>Worst</span>
                                <span>Not Good</span>
                                <span>Fine</span>
                                <span>Look Good</span>
                                <span>Very Good</span>
                            </div>
                            <input type="range" name="experience" min="1" max="5" value="3" id="experience" required>
                        </div>
                        <textarea name="comments" placeholder="Add your comments..." required></textarea>

                        <div class="button">
                            <button type="button" id="cancel" class="cancel">Cancel</button>
                            <button type="submit" class="send">Submit</button>
                        </div>
                    </form>
                </div>
            </section>

            <script src="navbar/navmover.js"></script>
            <script>
                const popupOuter = document.querySelector('.popup-outer');
                const closeBtns = document.querySelectorAll('.close, #cancel');
                const evaluateBtns = document.querySelectorAll('.evaluate-btn');

                // Open modal on "Evaluate"
                evaluateBtns.forEach(button => {
                    button.addEventListener('click', () => {
                        const event_id = button.getAttribute('data-event-id');
                        document.querySelector('input[name="event_id"]').value = event_id;
                        popupOuter.classList.add('active');
                    });
                });

                // Close modal on "Close" or "Cancel"
                closeBtns.forEach(btn => {
                    btn.addEventListener('click', () => {
                        popupOuter.classList.remove('active');
                    });
                });
            </script>

            <script>
                const rangeInput = document.querySelector('input[name="experience"]');
                const emojis = document.querySelectorAll('.emoji');

                rangeInput.addEventListener('input', function () {
                    const value = parseInt(rangeInput.value);

                    emojis.forEach((emoji, index) => {
                        if (index + 1 === value) {
                            emoji.classList.add('selected');
                            emoji.classList.remove('faded');
                        } else {
                            emoji.classList.remove('selected');
                            emoji.classList.add('faded');
                        }
                    });
                });

                rangeInput.dispatchEvent(new Event('input'));
            </script>
        </div>
    </body>

    </html>

    <?php
    // Close the database connection
    mysqli_close($conn);
    ?>
