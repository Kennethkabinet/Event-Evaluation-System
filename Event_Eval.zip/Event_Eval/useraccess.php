<?php

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Access</title>
  <script src="navbar/AdminNavloader.js" defer></script>
  <link rel="stylesheet" href="style/useracc.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
  <link rel="stylesheet" href="chatbot/chatbot.css">
  <link rel="stylesheet" href="style/table.css">
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght@400&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:wght@400&display=swap" rel="stylesheet">
</head>

<body>
  <div id="adminbar"></div>
  <div class="navbarmargin" style="margin-top:88px">
    <main>
      <h1 style="padding: 30px;">User Access</h1>
      <div class="table-container">
        <table class="styled-table">
          <thead>
            <tr>
              <th>Username</th>
              <th>Depeartment</th>
              <th>Email</th>
              <th>Access</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Kenneth Onan</td>
              <td>CICS</td>
              <td>user@gmail.com</td>
              <td>
                <button style="background-color: #b3e6cc; color: #006622; border: 1px solid #006622; padding: 5px 15px; border-radius: 5px; cursor: pointer;">Accept</button>
                <button style="background-color: #ffcccc; color: #cc0000; border: 1px solid #cc0000; padding: 5px 15px; border-radius: 5px; cursor: pointer;">Denied</button>
              </td>

            </tr>
          </tbody>
        </table>
      </div>
    </main>





    <div class="container-main">
      <!--Toggler -->
      <button id="chatbot-toggler">
        <span class="material-symbols-rounded">mode_comment</span>
        <span class="material-symbols-rounded">close</span>
      </button>

      <div class="chatbot-popup">
        <div class="chat-header">
          <div class="header-info">
            <img class="chatbot-logo" src="style/Images/chatbot.png" width="50" height="50" alt="Chatbot Logo">
            <h2 class="logo-text">Evalus Chatbot</h2>
          </div>
          <button id="close-chatbot" class="material-symbols-rounded">keyboard_arrow_down</button>
        </div>

        <!--Body -->
        <div class="chat-body">
          <div class="message bot-message">
            <img class="chatbot-logo" src="style/Images/chatbot-black.png" width="35" height="35" alt="Chatbot Logo">
            <div class="message-text"> Hello there! I'm Evalus. <br /> What can I assist you with today? I'm here to help! </div>
          </div>
        </div>

        <!--Footer -->
        <div class="chat-footer">
          <form action="#" class="chat-form">
            <textarea placeholder="Message..." class="message-input" required></textarea>
            <div class="chat-controls">
              <button type="button" id="emoji-picker" class="material-symbols-outlined">sentiment_satisfied</button>
              <div class="file-upload-wrapper">
                <input type="file" accept="image/*" id="file-input" hidden />
                <img src="#" />
                <button type="button" id="file-upload" class="material-symbols-rounded">attach_file</button>
                <button type="button" id="file-cancel" class="material-symbols-rounded">close</button>
              </div>
              <button type="submit" id="send-message" class="material-symbols-rounded">arrow_upward</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/emoji-mart@latest/dist/browser.js"></script>
    <script src="chatbot/chatbot.js"></script>
    <script src="navbar/navmover.js"></script>
</body>

</html>